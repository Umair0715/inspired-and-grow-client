import Sidebar from "components/global/sidebar";
import { BrowserRouter as Router , Routes , Route } from "react-router-dom";
import { ToastContainer } from 'react-toastify';
import { useState } from "react";
import Dashboard from "pages/dashboard";
import Users from "pages/userManagement";
import UserDetails from "pages/userManagement/UserDetails";
import AddUser from "pages/userManagement/AddUser";
import EditUser from "pages/userManagement/EditUser";
import Orders from "pages/orderManagement";
import PreBookings from "pages/orderManagement/PreBookings";


function App() {
    const [isLoginPage , setIsLoginPage] = useState(false);

    return (
        <div className="space">
            <ToastContainer 
                style={{fontSize: 15}}
                position="top-center"
                autoClose={3000}
                closeOnClick
                pauseOnHover
            />
            <Router>
            <Sidebar />
                <Routes>
                    <Route path='/' element={<Dashboard />} />
                    <Route path='/user-management/users' element={<Users />} />
                    <Route 
                    path='/user-management/users/:id' 
                    element={<UserDetails />} 
                    />
                    <Route 
                    path='/user-management/add-new'
                    element={<AddUser />}
                    />
                    <Route 
                    path='/user-management/edit-user/:id'
                    element={<EditUser />}
                    />
                    <Route 
                    path='/order-management/orders'
                    element={<Orders />}
                    />
                    <Route 
                    path='/order-management/pre-bookings'
                    element={<PreBookings />}
                    />

                </Routes>
            </Router>
        </div>
    );
}

export default App;
