import Layout from 'components/global/Layout';
import Search from 'components/global/Search';
import UsersTable from 'components/userManagement/UsersTable';
import React from 'react'
import { Link } from 'react-router-dom';

const Users = () => {
    return (
        <Layout>
            <div className='flex items-center justify-between'>
                <div>
                    <Search />
                </div>
                <div className='flex items-center gap-4'>
                    <Link to='/user-management/add-new'>
                        <button className="btn-primary py-2 px-12">ADD</button>
                    </Link>
                </div>
            </div>
            <div className='my-6'>
                <UsersTable />
            </div>
        </Layout>
    )
}

export default Users;