import Axios from "config/api";
import { addCategory, removeCategory, setCategories, setCreateLoading, setDeleteLoading , updateCategory , setLoading, setUpdateLoading, setPages, setCurrentPage, setSubCategories } from "redux/reducers/categoryReducer";


export const createCategory = (data , toast) => async (dispatch , getState) => {
    try {
        dispatch(setCreateLoading(true));
        const { token } = getState().auth.user;
        const { data : { data : { doc } } } = await Axios.post(`/categories` , data , {
            headers : {
                Authorization : `Bearer ${token}`
            }
        });
        dispatch(addCategory(doc));
        dispatch(setCreateLoading(false));
        toast.success('Category created successfully.');
    } catch (err) {
        dispatch(setCreateLoading(false));
        console.log('Create category error:' , err);
        toast.error(err?.response?.data?.message || err?.message || 'Something went wrong.');
    }
}


export const updateCat = (id , data , toast) => async (dispatch , getState) => {
    try {
        dispatch(setUpdateLoading(true));
        const { token } = getState().auth.user;
        const { data : { data : { doc } } } = await Axios.put(`/categories/${id}` , data  , 
        { headers : { Authorization : `Bearer ${token}`} });
        dispatch(updateCategory(doc));
        dispatch(setUpdateLoading(false));
        toast.success('Updated Successfully.');
    } catch (err) {
        dispatch(setUpdateLoading(false));
        console.log('Update Category error' , err);
        toast.error(err?.response?.data?.message || err?.message || 'Something went wrong.');
    }
}


export const getCategories = (toast , currentPage) => async (dispatch , getState) => {
    try {
        dispatch(setLoading(true));
        const { token } = getState().auth.user;
        const { data : { data : { docs , pages , page } } } = await Axios(`/categories?page=${getState().category.currentPage}` , {
            headers : {
                Authorization : `Bearer ${token}`
            }
        });
        dispatch(setCategories(docs));
        dispatch(setPages(pages));
        dispatch(setCurrentPage(page));
        dispatch(setLoading(false));
    } catch (err) {
        dispatch(setLoading(false));
        console.log('Get categories error:' , err);
        toast.error(err?.response?.data?.message || err?.message || 'Something went wrong.');
    }
}


export const deleteCategory = (id , toast) => async (dispatch , getState) => {
    try {
        dispatch(setDeleteLoading(true));
        const { token } = getState().auth.user;
        await Axios.delete(`/categories/${id}` , 
            { headers : { Authorization : `Bearer ${token}`} }
        );
        dispatch(removeCategory(id));
        dispatch(setDeleteLoading(false));
        toast.success('Deleted Successfully.');
    } catch (err) {
        dispatch(setDeleteLoading(false));
        console.log('Delete Category error' , err);
        toast.error(err?.response?.data?.message || err?.message || 'Something went wrong.');
    }
}


export const getTotalCategories = (toast) => async (dispatch) => {
    try {
        dispatch(setLoading(true));
        const { data : { data : { docs } } } = await Axios(`/categories/all`);
        dispatch(setCategories(docs));
        dispatch(setLoading(false));
    } catch (err) {
        dispatch(setLoading(false));
        console.log('Get Total categories error:' , err);
        toast.error(err?.response?.data?.message || err?.message || 'Something went wrong.');
    }
}

export const getSubCategories = (id , toast) => async (dispatch) => {
    try {
        dispatch(setLoading(true));
        const { data : { data : { docs } } } = await Axios(`/categories/sub/${id}`);
        dispatch(setSubCategories(docs));
        dispatch(setLoading(false));
    } catch (err) {
        dispatch(setLoading(false));
        console.log('Get Main Sub categories error:' , err);
        toast.error(err?.response?.data?.message || err?.message || 'Something went wrong.');
    }
}